/* WANTED engine: star ladder + simulated market. Works in browsers and Node. MIT. */
(function(r,f){if(typeof module=="object"&&module.exports)module.exports=f();else r.Wanted=f()})(typeof self!="undefined"?self:this,function(){
const TIERS=[{stars:1,mc:5000,label:"Launched"},{stars:2,mc:25000,label:"Gaining heat"},{stars:3,mc:69000,label:"Graduated: liquidity moves to a DEX"},{stars:4,mc:100000,label:"Most Wanted"},{stars:5,mc:500000,label:"Citywide manhunt"}];
const DECAY=0.9; // a star is lost only after mc falls 10% under its threshold
const DEMO=[["Duck","DUCK",9000],["Heist Crew","HEIST",31000],["Siren","SIREN",72000],["Palm Tree","PALM",4000],["Neon","NEON",120000],["Gator","GATR",18000],["Bail Bonds","BAIL",52000],["Marina","MRNA",6000]];
function starsFor(mc,prev){let n=Math.max(prev||1,1);while(n<5&&mc>=TIERS[n].mc)n++;while(n>1&&mc<TIERS[n-1].mc*DECAY)n--;return n}
const fmt=n=>"$"+Math.round(n).toLocaleString("en-US");
class Market{
 constructor(){this.coins=[];this.h={}}
 on(e,f){(this.h[e]=this.h[e]||[]).push(f)}
 emit(e,d){(this.h[e]||[]).forEach(f=>f(d))}
 launch(name,ticker,mc){mc=mc||5000;const s=starsFor(mc,1);const c={name,ticker,mc,stars:s,graduated:s>=3,hist:[mc]};this.coins.push(c);this.emit("launch",c);return c}
 tick(){this.coins.forEach(c=>{c.mc=Math.max(1000,c.mc*(1+(Math.random()-.47)*.09));c.hist.push(c.mc);if(c.hist.length>60)c.hist.shift();
  const n=starsFor(c.mc,c.stars);if(n!==c.stars){const up=n>c.stars;c.stars=n;if(n>=3&&!c.graduated){c.graduated=true;this.emit("graduate",c)}this.emit(up?"star_up":"star_down",c)}})}
}
function loadUser(){try{return JSON.parse(localStorage.getItem("wanted.coins")||"[]")}catch(e){return[]}}
function saveUser(l){try{localStorage.setItem("wanted.coins",JSON.stringify(l))}catch(e){}}
return{TIERS,DECAY,DEMO,starsFor,fmt,Market,loadUser,saveUser};
});

(function(){if(typeof document=="undefined")return;
 var T=Date.parse("2026-11-19T00:00:00-05:00"),p=function(n){return String(n).padStart(2,"0")};
 function tick(){var d=Math.max(0,T-Date.now()),s=Math.floor(d/1e3),v={d:Math.floor(s/86400),h:Math.floor(s%86400/3600),m:Math.floor(s%3600/60),s:s%60};
  document.querySelectorAll("[data-cd]").forEach(function(e){e.textContent=d?v.d+"d "+p(v.h)+"h "+p(v.m)+"m "+p(v.s)+"s":"GTA VI is out"});
  document.querySelectorAll("[data-p]").forEach(function(e){e.firstChild.textContent=p(v[e.dataset.p])})}
 document.addEventListener("DOMContentLoaded",function(){tick();setInterval(tick,1000)})})();
