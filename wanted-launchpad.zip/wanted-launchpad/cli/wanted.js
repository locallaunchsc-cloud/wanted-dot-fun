#!/usr/bin/env node
const W=require("../wanted.js");const [cmd,arg]=process.argv.slice(2);
if(cmd==="ladder"){W.TIERS.forEach(t=>console.log("*".repeat(t.stars).padEnd(6),W.fmt(t.mc).padEnd(10),t.label))}
else if(cmd==="stars"&&arg>=0){const mc=Number(arg);console.log(W.starsFor(mc)+" star(s) at "+W.fmt(mc))}
else if(cmd==="sim"){const m=new W.Market(),n=Number(arg)||200;W.DEMO.forEach(d=>m.launch(d[0],d[1],d[2]));
 ["star_up","star_down","graduate"].forEach(e=>m.on(e,c=>console.log(e.padEnd(10),"$"+c.ticker,c.stars+"*",W.fmt(c.mc))));
 for(let i=0;i<n;i++)m.tick()}
else console.log("usage: node cli/wanted.js ladder | stars <marketcap> | sim [ticks]");
